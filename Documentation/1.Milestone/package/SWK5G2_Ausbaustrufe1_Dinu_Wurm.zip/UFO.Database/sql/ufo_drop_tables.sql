SET foreign_key_checks = 0;
DROP TABLE `artist`;
DROP TABLE `category`;
DROP TABLE `country`;
DROP TABLE `performance`;
DROP TABLE `user`;
DROP TABLE `venue`;
SET foreign_key_checks = 1;