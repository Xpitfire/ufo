INSERT INTO `location` (`LocationId`, `Latitude`, `Longitude`, `Name`) VALUES
(1, 48.30576, 14.28673, 'Hauptplatz'),
(2, 48.30653, 14.28897, 'Pfarrplatz und Domgasse'),
(3, 48.30512, 14.28442, 'Altstadt'),
(4, 48.30366, 14.28846, 'Landstrasse'),
(5, 48.30360, 14.28576, 'Promenade'),
(6, 48.30366, 14.28846, 'Straßentheater');