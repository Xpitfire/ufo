INSERT INTO `category` (`CategoryId`, `Name`) VALUES 
('A', 'Akrobatik'),
('C', 'Comedy & Clownerie'),
('F', 'Feuershow'),
('J', 'Jonglage'),
('L', 'Luftakrobatik'),
('M', 'Musik'),
('OT', 'Figuren- und Objekttheater'),
('S', 'Samba'),
('St', 'Stehstill-Statue'),
('T', 'Tanz');