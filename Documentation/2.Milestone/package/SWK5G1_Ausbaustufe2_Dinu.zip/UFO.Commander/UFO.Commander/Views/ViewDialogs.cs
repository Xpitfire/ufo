﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MahApps.Metro.Controls.Dialogs;

namespace UFO.Commander.Views
{
    public class CustomViewDialog : CustomDialog
    {
    }

    public class CustomExceptionDialog : CustomDialog
    {
    }
}
