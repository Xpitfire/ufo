﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace UFO.Commander.Views.Dialogs
{
    /// <summary>
    /// Interaction logic for ArtistDialog.xaml
    /// </summary>
    public partial class ArtistDialog : UserControl
    {
        public ArtistDialog()
        {
            InitializeComponent();
        }

    }
}
